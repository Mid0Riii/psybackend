from django.apps import AppConfig


class StudentConfig(AppConfig):
    name = 'apps.student'
    verbose_name='学员信息管理'