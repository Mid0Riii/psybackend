from django.apps import AppConfig


class TeacherConfig(AppConfig):
    name = 'apps.teacher'
    verbose_name='教师授课信息记录'
