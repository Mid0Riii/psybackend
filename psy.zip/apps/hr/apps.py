from django.apps import AppConfig


class HumanresourcesConfig(AppConfig):
    name = 'hr'
    verbose_name = '员工信息管理'
