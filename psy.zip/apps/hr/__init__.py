
default_app_config = "hr.apps.HumanresourcesConfig"
