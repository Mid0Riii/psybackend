# -*- coding: utf-8 -*-

# version string following pep-0396 and pep-0386
__version__ = '1.5.0'  # pragma: nocover

default_app_config = 'filer.apps.FilerConfig'
